---
title: Curriculum Analysis
hidden: true
showthedate: false

links:
- icon: graduation-cap
  icon_pack: fas
  name: CSE Thesis
  url:  https://webcms3.cse.unsw.edu.au/THES0001/16s1/outline 
  
  
tags:
- data-analysis
- data-visualisation
- education
- cse-honours

---
![graph](/img/student-projects/graph.jpg)

## Context

The School of Computer Science and Enginnering at UNSW offers a bit more than 100 courses. 
Although some streams are defined to help students choose courses, it can be hard to nagivate and discriminate the link between courses (requirements, complementary).

We propose to build a tool for student to navigate visually on the curriulum and to recommend courses based on connected content.
Using the course handbooks and online material, we propose to compute a similarity metrics (extra topic from text and compare list of topics from different courses).



## Goals & Milestones

- Create the dataset by scraping the [CSE online Handbook](https://www.handbook.unsw.edu.au/ComputerScience/browse?sa=91ce03204f0f5b00eeb3eb4f0310c782) (collect html pages, build topic representaions of each courses)
- Compute Similarity and agency taking into account the topic representation, term of offering, teaching staff
- Design a UI tool to visual, explore, search the graph
- Design a recommender (highlight graph context) based on previous courses taken
- Implement a job matching tool: given a linkedin job, highlight enabling CSE courses 


## Topics

Data Analysis, Graph, HCI

## Prerequisites

- Skills: Python/Js and Git.

## References

- http://www.cs.cmu.edu/~hanxiaol/publications/yang-wsdm15.pdf
- https://github.com/quark0/CGL
- https://github.com/rbsteinm/EPFL-Courses-Graph-Representation
- https://github.com/LoomisLoud/epfl-course-recommendation
- https://github.com/RobertInjac/EPFL-Courses-Similarity
- https://developer.linkedin.com/docs/v1/jobs/job-lookup-api-and-fields
- https://github.com/axa-group/Parsr
