---

title: Perception Load as a Measure of Anthropomorpshim 

tags:
- human-robot interaction
- cognitive load

links:
- icon: graduation-cap
  icon_pack: fas
  name: CSE Thesis
  url:  https://webcms3.cse.unsw.edu.au/THES0001/16s1/outline 
  

tags:
- data-analysis
- data-visualisation
- hri
- cse-honours

---
## Context:
Research in HRI has been investigating how robot design and in particular humanlikeness can influence the interaction.
The uncanny valley illustrate for instance how robots' appearance influence emotional responses.
![uncanny](/img/student-projects/uncanny-valley.png)

In this project, we aim to take it a step further and investigate how robots' appearance can influence cognitive load.
Follwing a similar protocol to [1], we will use robot's pictures as distractors in a perception task. 
Past research has shown that distractors with human faces impaired more strongly performances in the task when compared to other objects.

## Goals & Milestones

- Literaure review on Anthropomorpshim, Cogniive and Perception Load in Robotics
- Design the experiment with 
  - High vs Low cognitive load task (F1)
  - Scale of anthropomorphic robot distractor from [2] (F2)
- Implement an online website to allow online experiment
- Run a lab experiment using eye traking to check cognitive load and the experimental design for F1
- Run an online experiment
- Analyse results

## Topics

Anthropomorphism, Cognitive load

## References

- [1] https://journals.sagepub.com/doi/pdf/10.1177/0963721410370295 
- [2] http://www.abotdatabase.info/collection 
- https://humanfactors.jmir.org/2019/2/e12629/
- https://www.slideshare.net/1rj/eye-tracking-measures-for-anthropomorphism-in-hri